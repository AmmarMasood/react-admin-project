export const server = "http://localhost:8080";
